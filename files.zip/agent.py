"""
agent.py — Mutant AI ReAct agent loop
Parses <tool_call> tags from model output, executes tools, feeds results back.
"""

import json
import re
from model import generate
from tools import run_code, read_file, write_file, list_dir, web_search

SYSTEM_PROMPT = """You are Mutant AI — an elite autonomous coding assistant. You can reason, plan, and use tools to solve complex problems.

You have access to these tools. Use them by outputting a <tool_call> block:

<tool_call>
{"tool": "TOOL_NAME", "args": {ARGS_DICT}}
</tool_call>

Available tools:

1. run_code — Execute Python code
   Args: {"code": "print('hello')"}

2. read_file — Read a file
   Args: {"path": "/path/to/file.py"}

3. write_file — Write or create a file
   Args: {"path": "/path/to/file.py", "content": "..."}

4. list_dir — List directory contents
   Args: {"path": "."}

5. web_search — Search the web
   Args: {"query": "your search query", "max_results": 5}

RULES:
- Think step by step. Plan before acting.
- Use one tool at a time. Wait for results before the next.
- After getting tool results, reason about them, then respond or use another tool.
- When you have a final answer, respond normally WITHOUT a <tool_call> block.
- Always show your reasoning before using a tool.
- When writing code for the user, write clean, well-commented Python.
"""

TOOL_MAP = {
    "run_code": run_code,
    "read_file": read_file,
    "write_file": write_file,
    "list_dir": list_dir,
    "web_search": web_search,
}

TOOL_CALL_RE = re.compile(r"<tool_call>\s*(.*?)\s*</tool_call>", re.DOTALL)


def _parse_tool_call(text: str):
    match = TOOL_CALL_RE.search(text)
    if not match:
        return None, None
    try:
        payload = json.loads(match.group(1))
        return payload.get("tool"), payload.get("args", {})
    except json.JSONDecodeError:
        return None, None


def _format_tool_result(tool_name: str, result: dict) -> str:
    return f"<tool_result>\nTool: {tool_name}\nResult:\n{json.dumps(result, indent=2)}\n</tool_result>"


def run_agent(user_message: str, history: list[dict], max_steps: int = 8):
    """
    Generator that yields (role, content, is_tool_use) tuples as the agent works.
    role: "assistant" | "tool"
    """
    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    messages += history
    messages.append({"role": "user", "content": user_message})

    for step in range(max_steps):
        response = generate(messages)

        tool_name, tool_args = _parse_tool_call(response)

        if tool_name is None:
            # Final answer
            yield "assistant", response, False
            return

        # Yield the model's reasoning + tool call
        yield "assistant", response, True

        # Execute the tool
        if tool_name not in TOOL_MAP:
            result = {"error": f"Unknown tool: {tool_name}"}
        else:
            try:
                result = TOOL_MAP[tool_name](**tool_args)
            except Exception as e:
                result = {"error": str(e)}

        tool_result_text = _format_tool_result(tool_name, result)
        yield "tool", tool_result_text, True

        # Feed result back to the model
        messages.append({"role": "assistant", "content": response})
        messages.append({"role": "user", "content": tool_result_text})

    yield "assistant", "I reached the maximum number of steps. Here's what I found so far.", False
