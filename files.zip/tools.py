"""
tools.py — Mutant AI agent tools
  • run_code     : execute Python in a subprocess sandbox
  • read_file    : read any text file on disk
  • write_file   : write / overwrite a file on disk
  • web_search   : DuckDuckGo search, returns top N snippets
"""

import subprocess
import sys
import tempfile
import os
import textwrap
from pathlib import Path
from duckduckgo_search import DDGS


# ─────────────────────────────────────────────
# 1. Code Runner
# ─────────────────────────────────────────────

def run_code(code: str, timeout: int = 30) -> dict:
    """
    Execute Python code in a temp file subprocess.
    Returns {"stdout": ..., "stderr": ..., "returncode": ...}
    """
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", delete=False, encoding="utf-8"
    ) as f:
        f.write(textwrap.dedent(code))
        tmp_path = f.name

    try:
        result = subprocess.run(
            [sys.executable, tmp_path],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return {
            "stdout": result.stdout.strip(),
            "stderr": result.stderr.strip(),
            "returncode": result.returncode,
        }
    except subprocess.TimeoutExpired:
        return {
            "stdout": "",
            "stderr": f"[Timeout] Code exceeded {timeout}s limit.",
            "returncode": -1,
        }
    finally:
        os.unlink(tmp_path)


# ─────────────────────────────────────────────
# 2. File Editor
# ─────────────────────────────────────────────

def read_file(path: str) -> dict:
    """Read a file and return its contents."""
    try:
        p = Path(path).expanduser().resolve()
        content = p.read_text(encoding="utf-8")
        return {"success": True, "path": str(p), "content": content}
    except Exception as e:
        return {"success": False, "error": str(e)}


def write_file(path: str, content: str) -> dict:
    """Write content to a file, creating parent dirs if needed."""
    try:
        p = Path(path).expanduser().resolve()
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        return {"success": True, "path": str(p), "bytes_written": len(content.encode())}
    except Exception as e:
        return {"success": False, "error": str(e)}


def list_dir(path: str = ".") -> dict:
    """List files and folders in a directory."""
    try:
        p = Path(path).expanduser().resolve()
        entries = sorted(p.iterdir(), key=lambda x: (x.is_file(), x.name))
        items = [
            {"name": e.name, "type": "file" if e.is_file() else "dir"}
            for e in entries
        ]
        return {"success": True, "path": str(p), "items": items}
    except Exception as e:
        return {"success": False, "error": str(e)}


# ─────────────────────────────────────────────
# 3. Web Search
# ─────────────────────────────────────────────

def web_search(query: str, max_results: int = 5) -> dict:
    """Search DuckDuckGo and return top result snippets."""
    try:
        with DDGS() as ddgs:
            results = list(ddgs.text(query, max_results=max_results))
        snippets = [
            {
                "title": r.get("title", ""),
                "snippet": r.get("body", ""),
                "url": r.get("href", ""),
            }
            for r in results
        ]
        return {"success": True, "query": query, "results": snippets}
    except Exception as e:
        return {"success": False, "error": str(e), "results": []}
