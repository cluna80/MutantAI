"""
app.py — Mutant AI Streamlit Interface
Run: streamlit run app.py
"""

import streamlit as st
from agent import run_agent

# ─────────────────────────────────────────────
# Page Config
# ─────────────────────────────────────────────
st.set_page_config(
    page_title="Mutant AI",
    page_icon="🧬",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─────────────────────────────────────────────
# Styles
# ─────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Rajdhani:wght@400;600;700&display=swap');

html, body, [class*="css"] {
    font-family: 'Rajdhani', sans-serif;
    background-color: #0a0a0f;
    color: #e0e0e0;
}

/* Sidebar */
[data-testid="stSidebar"] {
    background: #0d0d1a;
    border-right: 1px solid #1f1f3a;
}

/* Title */
.mutant-title {
    font-family: 'Share Tech Mono', monospace;
    font-size: 2.2rem;
    color: #00ffcc;
    text-shadow: 0 0 20px #00ffcc88;
    letter-spacing: 4px;
    margin-bottom: 0;
}
.mutant-sub {
    color: #666;
    font-size: 0.85rem;
    letter-spacing: 2px;
    margin-top: 0;
    font-family: 'Share Tech Mono', monospace;
}

/* Chat bubbles */
.msg-user {
    background: #12122a;
    border-left: 3px solid #7b5ea7;
    padding: 14px 18px;
    border-radius: 0 8px 8px 0;
    margin: 10px 0;
    font-size: 1rem;
}
.msg-assistant {
    background: #0d1a15;
    border-left: 3px solid #00ffcc;
    padding: 14px 18px;
    border-radius: 0 8px 8px 0;
    margin: 10px 0;
    font-family: 'Rajdhani', sans-serif;
    font-size: 1rem;
}
.msg-tool {
    background: #1a1a0d;
    border-left: 3px solid #ffcc00;
    padding: 10px 14px;
    border-radius: 0 6px 6px 0;
    margin: 6px 0 6px 20px;
    font-family: 'Share Tech Mono', monospace;
    font-size: 0.78rem;
    color: #aaa;
}

/* Label badges */
.badge-user { color: #7b5ea7; font-size: 0.7rem; letter-spacing: 2px; font-family: 'Share Tech Mono', monospace; }
.badge-ai   { color: #00ffcc; font-size: 0.7rem; letter-spacing: 2px; font-family: 'Share Tech Mono', monospace; }
.badge-tool { color: #ffcc00; font-size: 0.7rem; letter-spacing: 2px; font-family: 'Share Tech Mono', monospace; }

/* Input box */
.stTextArea textarea {
    background: #0d0d1a !important;
    border: 1px solid #1f1f3a !important;
    color: #e0e0e0 !important;
    font-family: 'Share Tech Mono', monospace !important;
    font-size: 0.9rem !important;
}

/* Buttons */
.stButton > button {
    background: linear-gradient(135deg, #00ffcc22, #7b5ea722);
    border: 1px solid #00ffcc55;
    color: #00ffcc;
    font-family: 'Share Tech Mono', monospace;
    letter-spacing: 2px;
    font-size: 0.8rem;
    padding: 8px 20px;
    border-radius: 4px;
    transition: all 0.2s;
}
.stButton > button:hover {
    background: linear-gradient(135deg, #00ffcc44, #7b5ea744);
    border-color: #00ffcc;
    box-shadow: 0 0 12px #00ffcc44;
}

/* Divider */
hr { border-color: #1f1f3a; }

/* Scrollbar */
::-webkit-scrollbar { width: 4px; }
::-webkit-scrollbar-track { background: #0a0a0f; }
::-webkit-scrollbar-thumb { background: #00ffcc44; border-radius: 2px; }
</style>
""", unsafe_allow_html=True)


# ─────────────────────────────────────────────
# Sidebar
# ─────────────────────────────────────────────
with st.sidebar:
    st.markdown('<p class="mutant-title">🧬 MUTANT</p>', unsafe_allow_html=True)
    st.markdown('<p class="mutant-sub">// autonomous AI agent</p>', unsafe_allow_html=True)
    st.markdown("---")

    st.markdown("**⚡ TOOLS ACTIVE**")
    st.markdown("🐍 `run_code` — Python executor")
    st.markdown("📂 `read_file` — File reader")
    st.markdown("✏️ `write_file` — File writer")
    st.markdown("📁 `list_dir` — Directory browser")
    st.markdown("🌐 `web_search` — DuckDuckGo")
    st.markdown("---")

    st.markdown("**🧠 MODEL**")
    st.markdown("`Qwen2.5-7B-Instruct`")
    st.markdown("---")

    st.markdown("**💡 EXAMPLE PROMPTS**")
    example_prompts = [
        "Search the web for the latest Qwen model updates",
        "Write a Python script that sorts a list of files by size",
        "Read the file at ./app.py and explain what it does",
        "Create a file called hello.py that prints Hello World",
        "List all files in the current directory",
        "Write and run a Python fibonacci sequence generator",
    ]
    for ep in example_prompts:
        if st.button(ep, key=ep):
            st.session_state["prefill"] = ep
    
    st.markdown("---")
    if st.button("🗑️ CLEAR CHAT"):
        st.session_state.messages = []
        st.session_state.history = []
        st.rerun()


# ─────────────────────────────────────────────
# State
# ─────────────────────────────────────────────
if "messages" not in st.session_state:
    st.session_state.messages = []  # Display messages
if "history" not in st.session_state:
    st.session_state.history = []   # Model conversation history


# ─────────────────────────────────────────────
# Header
# ─────────────────────────────────────────────
col1, col2 = st.columns([3, 1])
with col1:
    st.markdown('<h1 class="mutant-title">🧬 MUTANT AI</h1>', unsafe_allow_html=True)
    st.markdown('<p class="mutant-sub">// Qwen 2.5 7B · Code · Files · Web · Local</p>', unsafe_allow_html=True)
st.markdown("---")


# ─────────────────────────────────────────────
# Chat Display
# ─────────────────────────────────────────────
chat_container = st.container()
with chat_container:
    for msg in st.session_state.messages:
        role = msg["role"]
        content = msg["content"]

        if role == "user":
            st.markdown(f'<p class="badge-user">▸ YOU</p>', unsafe_allow_html=True)
            st.markdown(f'<div class="msg-user">{content}</div>', unsafe_allow_html=True)

        elif role == "assistant":
            st.markdown(f'<p class="badge-ai">▸ MUTANT AI</p>', unsafe_allow_html=True)
            st.markdown(f'<div class="msg-assistant">{content}</div>', unsafe_allow_html=True)

        elif role == "tool":
            st.markdown(f'<p class="badge-tool">⚙ TOOL RESULT</p>', unsafe_allow_html=True)
            st.markdown(f'<div class="msg-tool"><pre>{content}</pre></div>', unsafe_allow_html=True)


# ─────────────────────────────────────────────
# Input
# ─────────────────────────────────────────────
st.markdown("---")

prefill = st.session_state.pop("prefill", "")
user_input = st.text_area(
    "Message Mutant AI",
    value=prefill,
    placeholder="Ask me anything — I can code, search the web, read and write files...",
    height=100,
    key="user_input",
    label_visibility="collapsed",
)

col_send, col_space = st.columns([1, 5])
with col_send:
    send = st.button("⚡ SEND", use_container_width=True)

if send and user_input.strip():
    user_msg = user_input.strip()

    # Add to display
    st.session_state.messages.append({"role": "user", "content": user_msg})

    # Run agent
    with st.spinner("🧬 Mutant AI thinking..."):
        full_assistant_response = ""
        current_history = st.session_state.history.copy()

        for role, content, is_tool_step in run_agent(user_msg, current_history):
            st.session_state.messages.append({"role": role, "content": content})

            if role == "assistant" and not is_tool_step:
                # Final answer — update conversation history
                st.session_state.history.append({"role": "user", "content": user_msg})
                st.session_state.history.append({"role": "assistant", "content": content})

    st.rerun()
